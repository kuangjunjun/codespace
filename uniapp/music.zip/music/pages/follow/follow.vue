<template>
	<view class="follow">
		<wyheader icon="plus-filled">
			<template v-slot:content>
				<text>动态</text>
			</template>
		</wyheader>
		关注
	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		}
	}
</script>

<style lang="scss">

</style>